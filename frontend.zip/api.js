const API_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? 'http://localhost:5002/api'
    : 'https://zenbook-backend.onrender.com/api'; // Replace with your actual backend URL after deployment

const api = {
    async fetch(endpoint, options = {}) {
        const token = localStorage.getItem('token');
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers,
        };

        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        try {
            const response = await fetch(`${API_URL}${endpoint}`, {
                ...options,
                headers
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Something went wrong');
            return data;
        } catch (err) {
            console.error('API Error:', err);
            throw err;
        }
    },

    auth: {
        login: (credentials) => api.fetch('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
        register: (details) => api.fetch('/auth/register', { method: 'POST', body: JSON.stringify(details) }),
    },

    appointments: {
        book: (data) => api.fetch('/appointments', { method: 'POST', body: JSON.stringify(data) }),
        getSlots: (date) => api.fetch(`/appointments/slots/${date}`),
        getMy: () => api.fetch('/appointments/my'),
        getAll: () => api.fetch('/appointments/all'),
        update: (id, data) => api.fetch(`/appointments/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
        adminUpdate: (id, status) => api.fetch(`/appointments/admin/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    }
};
