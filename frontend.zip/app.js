// State
let state = {
    user: JSON.parse(localStorage.getItem('user')) || null,
    currentPath: window.location.pathname || '/',
    editingAppointment: null
};

// Router
const navigate = (path) => {
    state.currentPath = path;
    window.history.pushState({}, '', path);
    render();
};

const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    state.user = null;
    navigate('/login');
};

const showToast = (message, type = 'success') => {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast status-${type}`;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3000);
};

// Global handlers
window.navigate = navigate;
window.logout = logout;

window.selectSlot = (el, time) => {
    if (el.classList.contains('taken')) return;
    document.querySelectorAll('.slot-chip').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('selected-slot').value = time;
};

window.cancelAppointment = async (id) => {
    if (!confirm('Are you sure you want to cancel?')) return;
    try {
        await api.appointments.update(id, { status: 'cancelled' });
        showToast('Appointment cancelled');
        render();
    } catch (err) {
        showToast(err.message, 'error');
    }
};

window.editAppointment = (id, date, time, desc) => {
    state.editingAppointment = { id, date, time, description: desc };
    navigate('/book');
};

window.updateStatus = async (id, status) => {
    try {
        await api.appointments.adminUpdate(id, status);
        showToast(`Appointment ${status}`);
        render();
    } catch (err) {
        showToast(err.message, 'error');
    }
};

window.handleDateChange = async (date) => {
    const slotsGrid = document.querySelector('.slots-grid');
    if (!slotsGrid) return;

    slotsGrid.innerHTML = '<p>Loading slots...</p>';
    try {
        const takenSlots = await api.appointments.getSlots(date);
        const allSlots = ['09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00'];

        slotsGrid.innerHTML = allSlots.map(s => {
            const isTaken = takenSlots.includes(s);
            const isSelected = state.editingAppointment && state.editingAppointment.time === s && state.editingAppointment.date === date;
            return `
                <div class="slot-chip ${isTaken ? 'taken' : ''} ${isSelected ? 'selected' : ''}" 
                     onclick="selectSlot(this, '${s}')">
                    ${s} ${isTaken ? '(Booked)' : ''}
                </div>
            `;
        }).join('');

        if (state.editingAppointment && state.editingAppointment.date === date) {
            document.getElementById('selected-slot').value = state.editingAppointment.time;
        } else {
            document.getElementById('selected-slot').value = '';
        }
    } catch (err) {
        showToast('Error fetching slots', 'error');
    }
};

// Render logic
const render = async () => {
    const main = document.getElementById('main-content');
    const nav = document.getElementById('navbar');

    nav.innerHTML = Components.navbar(state.user);

    const path = state.currentPath;

    if (path === '/' || path === '/home') {
        main.innerHTML = Components.hero();
    }
    else if (path === '/login') {
        if (state.user) { navigate('/dashboard'); return; }
        main.innerHTML = Components.loginForm();
        setupLoginForm();
    }
    else if (path === '/register') {
        if (state.user) { navigate('/dashboard'); return; }
        main.innerHTML = Components.registerForm();
        setupRegisterForm();
    }
    else if (path === '/dashboard') {
        if (!state.user) { navigate('/login'); return; }
        main.innerHTML = '<div class="container"><h1>Loading...</h1></div>';
        try {
            const appointments = await api.appointments.getMy();
            main.innerHTML = Components.dashboard(state.user, appointments);
        } catch (err) {
            showToast('Failed to load appointments', 'error');
        }
    }
    else if (path === '/book') {
        if (!state.user) { navigate('/login'); return; }
        main.innerHTML = Components.bookingPage(state.editingAppointment);
        setupBookingForm();
        // Trigger initial slot check if editing or default today
        const dateInput = document.getElementById('book-date');
        if (dateInput.value) handleDateChange(dateInput.value);
    }
    else if (path === '/admin') {
        if (!state.user || state.user.role !== 'admin') { navigate('/'); return; }
        main.innerHTML = '<div class="container"><h1>Loading...</h1></div>';
        try {
            const appointments = await api.appointments.getAll();
            main.innerHTML = Components.adminDashboard(appointments);
        } catch (err) {
            showToast('Failed to load admin data', 'error');
        }
    }
};

function setupLoginForm() {
    const form = document.getElementById('login-form');
    if (form) {
        form.onsubmit = async (e) => {
            e.preventDefault();
            try {
                const res = await api.auth.login({
                    email: form.email.value,
                    password: form.password.value
                });
                localStorage.setItem('token', res.token);
                localStorage.setItem('user', JSON.stringify(res.user));
                state.user = res.user;
                showToast('Welcome back!');
                navigate('/dashboard');
            } catch (err) {
                showToast(err.message, 'error');
            }
        };
    }
}

function setupRegisterForm() {
    const form = document.getElementById('register-form');
    if (form) {
        form.onsubmit = async (e) => {
            e.preventDefault();
            try {
                await api.auth.register({
                    name: form.name.value,
                    email: form.email.value,
                    password: form.password.value,
                    role: form.role.value
                });
                showToast('Registration successful! Please login.');
                navigate('/login');
            } catch (err) {
                showToast(err.message, 'error');
            }
        };
    }
}

function setupBookingForm() {
    const form = document.getElementById('booking-form');
    if (form) {
        form.onsubmit = async (e) => {
            e.preventDefault();
            const slot = document.getElementById('selected-slot').value;
            if (!slot) {
                showToast('Please select a time slot', 'error');
                return;
            }
            try {
                const data = {
                    date: form['book-date'].value,
                    time: slot,
                    description: form['book-desc'].value
                };

                if (state.editingAppointment) {
                    await api.appointments.update(state.editingAppointment.id, data);
                    showToast('Appointment updated successfully!');
                    state.editingAppointment = null;
                } else {
                    await api.appointments.book(data);
                    showToast('Appointment booked successfully!');
                }
                navigate('/dashboard');
            } catch (err) {
                showToast(err.message, 'error');
            }
        };
    }
}

window.addEventListener('popstate', () => {
    state.currentPath = window.location.pathname;
    render();
});

render();
