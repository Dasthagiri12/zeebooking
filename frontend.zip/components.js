const Components = {
    navbar: (user) => `
        <div class="brand" onclick="navigate('/')">
            <ion-icon name="calendar-outline"></ion-icon>
            ZenBook
        </div>
        <ul class="nav-links">
            <li><a onclick="navigate('/')">Home</a></li>
            ${user ? `
                <li><a onclick="navigate('/dashboard')">Dashboard</a></li>
                ${user.role === 'admin' ? '<li><a onclick="navigate(\'/admin\')">Admin</a></li>' : ''}
                <li><a onclick="logout()">Logout</a></li>
                <li class="user-pill"><span class="btn btn-outline" style="padding: 0.4rem 1rem; border-radius: 2rem;">Hi, ${user.name}</span></li>
            ` : `
                <li><a onclick="navigate('/login')">Login</a></li>
                <li><a onclick="navigate('/register')" class="btn btn-primary" style="padding: 0.5rem 1.2rem;">Get Started</a></li>
            `}
        </ul>
    `,

    hero: () => `
        <div class="hero fade-in">
            <h1>Effortless Bookings, <br><span style="color: var(--secondary)">Seamless Experience.</span></h1>
            <p>The premium appointment management system designed for clarity and speed. Manage your schedule with grace.</p>
            <div style="display: flex; gap: 1rem; justify-content: center;">
                <button onclick="navigate('/register')" class="btn btn-primary">Start Booking Now</button>
                <button onclick="navigate('/login')" class="btn btn-outline">Explore Features</button>
            </div>
        </div>
    `,

    loginForm: () => `
        <div class="container fade-in" style="max-width: 550px; margin-top: 4rem;">
            <div class="card">
                <div style="text-align: center; margin-bottom: 2.5rem;">
                    <ion-icon name="lock-closed-outline" style="font-size: 3.2rem; color: var(--primary); margin-bottom: 1.5rem;"></ion-icon>
                    <h1 style="font-size: 2.5rem; margin-bottom: 0.5rem; font-weight: 800;">Welcome Back</h1>
                    <p style="color: var(--text-muted); font-size: 1.1rem;">Access your premium booking dashboard.</p>
                </div>
                <form id="login-form">
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" id="email" required placeholder="your@email.com">
                    </div>
                    <div class="form-group" style="margin-bottom: 2.5rem;">
                        <label>Secure Password</label>
                        <input type="password" id="password" required placeholder="••••••••">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">Sign Into Account</button>
                </form>
                <div style="text-align: center; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--glass-border);">
                    <p style="color: var(--text-muted);">New to ZenBook? <a onclick="navigate('/register')" style="color: var(--secondary); cursor: pointer; font-weight: 700;">Create an account</a></p>
                </div>
            </div>
        </div>
    `,

    registerForm: () => `
        <div class="container fade-in" style="max-width: 550px; margin-top: 3rem;">
            <div class="card">
                <div style="text-align: center; margin-bottom: 2.5rem;">
                    <ion-icon name="person-add-outline" style="font-size: 3.2rem; color: var(--secondary); margin-bottom: 1.5rem;"></ion-icon>
                    <h1 style="font-size: 2.5rem; margin-bottom: 0.5rem; font-weight: 800;">Join ZenBook</h1>
                    <p style="color: var(--text-muted); font-size: 1.1rem;">Start managing your schedule with grace.</p>
                </div>
                <form id="register-form">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="name" required placeholder="John Doe">
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" id="email" required placeholder="john@example.com">
                    </div>
                    <div class="form-group">
                        <label>Secure Password</label>
                        <input type="password" id="password" required placeholder="At least 8 characters">
                    </div>
                    <div class="form-group" style="margin-bottom: 2.5rem;">
                        <label>Choose Account Type</label>
                        <select id="role" style="cursor: pointer;">
                            <option value="user">Standard User</option>
                            <option value="admin">System Admin</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">Create My Account</button>
                </form>
                <div style="text-align: center; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--glass-border);">
                    <p style="color: var(--text-muted);">Already a member? <a onclick="navigate('/login')" style="color: var(--secondary); cursor: pointer; font-weight: 700;">Sign in here</a></p>
                </div>
            </div>
        </div>
    `,

    dashboard: (user, appointments) => `
        <div class="container fade-in">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 3rem;">
                <div>
                    <h1 style="font-size: 3rem; margin-bottom: 0.5rem;">Your Schedule</h1>
                    <p style="color: var(--text-muted); font-size: 1.1rem;">Welcome back, <strong>${user.name}</strong>. You have ${appointments.length} appointment(s).</p>
                </div>
                <button onclick="navigate('/book')" class="btn btn-primary">
                    <ion-icon name="add-outline" style="font-size: 1.5rem;"></ion-icon> New Booking
                </button>
            </div>
            
            <div class="appointment-grid">
                ${appointments.length === 0 ? `
                    <div class="card" style="grid-column: 1/-1; text-align: center; padding: 4rem;">
                        <ion-icon name="calendar-outline" style="font-size: 4rem; color: var(--primary); margin-bottom: 1rem; opacity: 0.5;"></ion-icon>
                        <h2 style="margin-bottom: 1rem;">No Appointments Yet</h2>
                        <p style="color: var(--text-muted); margin-bottom: 2rem;">Ready to schedule your first session?</p>
                        <button onclick="navigate('/book')" class="btn btn-outline">Book Your First Appointment</button>
                    </div>
                ` :
            appointments.map(app => `
                    <div class="appointment-card fade-in">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem;">
                            <span class="status-badge status-${app.status}">${app.status}</span>
                            <div style="text-align: right;">
                                <div style="font-weight: 700; color: var(--text-white);">${app.date}</div>
                                <div style="color: var(--secondary); font-weight: 600;">${app.time}</div>
                            </div>
                        </div>
                        <p style="margin: 1.5rem 0; color: var(--text-muted); line-height: 1.5; min-height: 3rem;">${app.description || 'No description provided.'}</p>
                        ${app.status === 'pending' ? `
                            <div style="display: flex; gap: 0.75rem; border-top: 1px solid var(--glass-border); padding-top: 1.5rem; margin-top: 1rem;">
                                <button onclick="editAppointment('${app._id}', '${app.date}', '${app.time}', '${app.description || ''}')" class="btn btn-outline" style="flex: 1; padding: 0.6rem;">Edit</button>
                                <button onclick="cancelAppointment('${app._id}')" class="btn btn-outline" style="flex: 1; padding: 0.6rem; color: var(--error); border-color: rgba(239, 68, 68, 0.2);">Cancel</button>
                            </div>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
        </div>
    `,

    bookingPage: (editing) => {
        const today = new Date().toISOString().split('T')[0];
        return `
            <div class="container fade-in" style="max-width: 900px;">
                <div class="card">
                    <div style="text-align: center; margin-bottom: 3rem;">
                        <h1 style="font-size: 2.5rem; margin-bottom: 0.5rem;">${editing ? 'Modify Appointment' : 'Book a Session'}</h1>
                        <p style="color: var(--text-muted)">${editing ? 'Adjust your date, time or details below.' : 'Select a preferred time and date for your visit.'}</p>
                    </div>
                    
                    <form id="booking-form">
                        <div class="form-group">
                            <label><ion-icon name="calendar-clear-outline"></ion-icon> 1. Choose Date</label>
                            <input type="date" id="book-date" required min="${today}" 
                                   value="${editing ? editing.date : today}"
                                   onchange="handleDateChange(this.value)">
                        </div>
                        
                        <div class="form-group">
                            <label><ion-icon name="time-outline"></ion-icon> 2. Select Time Slot</label>
                            <div class="slots-grid">
                                <!-- Slots will be injected here via JS -->
                                <p style="color: var(--text-muted)">Please select a date first...</p>
                            </div>
                            <input type="hidden" id="selected-slot" required value="${editing ? editing.time : ''}">
                        </div>

                        <div class="form-group">
                            <label><ion-icon name="document-text-outline"></ion-icon> 3. Additional Details</label>
                            <textarea id="book-desc" rows="4" placeholder="Briefly describe the purpose of your appointment...">${editing ? editing.description : ''}</textarea>
                        </div>

                        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                            <button type="submit" class="btn btn-primary" style="flex: 2;">
                                ${editing ? 'Save Changes' : 'Confirm Booking'}
                            </button>
                            <button type="button" onclick="navigate('/dashboard')" class="btn btn-outline" style="flex: 1;">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    },

    adminDashboard: (appointments) => `
        <div class="container fade-in">
            <div style="margin-bottom: 3rem;">
                <h1 style="font-size: 3rem; margin-bottom: 0.5rem;">System Administration</h1>
                <p style="color: var(--text-muted); font-size: 1.1rem;">Manage all system appointments and user requests.</p>
            </div>
            
            <div class="card" style="padding: 0; overflow: hidden;">
                <table style="width: 100%; border-collapse: collapse; text-align: left;">
                    <thead style="background: rgba(255, 255, 255, 0.03);">
                        <tr style="color: var(--text-muted); border-bottom: 1px solid var(--glass-border);">
                            <th style="padding: 1.5rem 2rem;">User Details</th>
                            <th style="padding: 1.5rem 2rem;">Schedule</th>
                            <th style="padding: 1.5rem 2rem;">Current Status</th>
                            <th style="padding: 1.5rem 2rem;">Control</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${appointments.length === 0 ? '<tr><td colspan="4" style="padding: 4rem; text-align: center; color: var(--text-muted);">No system activity recorded yet.</td></tr>' :
            appointments.map(app => `
                            <tr style="border-bottom: 1px solid var(--glass-border); transition: 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.02)'" onmouseout="this.style.background='transparent'">
                                <td style="padding: 1.5rem 2rem;">
                                    <div style="font-weight: 700; color: var(--text-white); font-size: 1.1rem;">${app.userId ? app.userId.name : 'Unknown User'}</div>
                                    <div style="font-size: 0.9rem; color: var(--text-muted)">${app.userId ? app.userId.email : 'N/A'}</div>
                                </td>
                                <td style="padding: 1.5rem 2rem;">
                                    <div style="font-weight: 600;">${app.date}</div>
                                    <div style="color: var(--secondary); font-size: 0.95rem;">at ${app.time}</div>
                                </td>
                                <td style="padding: 1.5rem 2rem;">
                                    <span class="status-badge status-${app.status}">${app.status}</span>
                                </td>
                                <td style="padding: 1.5rem 2rem;">
                                    ${app.status === 'pending' ? `
                                        <div style="display: flex; gap: 0.5rem;">
                                            <button onclick="updateStatus('${app._id}', 'approved')" class="btn btn-primary" style="padding: 0.5rem 1rem; font-size: 0.85rem;">Approve</button>
                                            <button onclick="updateStatus('${app._id}', 'rejected')" class="btn btn-outline" style="padding: 0.5rem 1rem; font-size: 0.85rem; color: var(--error);">Reject</button>
                                        </div>
                                    ` : `
                                        <span style="color: var(--text-muted); font-size: 0.9rem;">No actions available</span>
                                    `}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `
};
